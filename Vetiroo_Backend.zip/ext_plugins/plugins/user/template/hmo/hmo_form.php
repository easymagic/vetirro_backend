<!-- hmo form -->

<h3>HMO Registration</h3>

	<div class="col-xs-12" style="margin-top: 11px;">
		<label>
			Company Name
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[name]" required="" class="form-control"/>
	</div>


	
	<div class="col-xs-12">
		<label>
			E-mail
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[email]" required="" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input type="number" name="user[phone]" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[address]" class="form-control"/>
	</div>





	<div class="col-xs-12">
		<label>
			Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="user[password]" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Confirm Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="password2" class="form-control" />
	</div>


    <input type="hidden" name="type" value="hmo" />
