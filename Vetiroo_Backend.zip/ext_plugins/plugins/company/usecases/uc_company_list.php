<?php 

function uc_company_list($type=''){
 
 $criteria = array();
 $account = session('admin_account');


 if (!empty($type))$criteria['type'] = $type;
 $criteria['created_by'] = $account->company_id;

 response('data',__action('entity_get_where','company',$criteria));


}
add_listener('uc_company_list','uc_company_list');