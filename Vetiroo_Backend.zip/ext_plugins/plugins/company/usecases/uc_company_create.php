<?php 

function uc_company_create(){
 
  $account = session('admin_account');
  
  $company = request('company');
  $company['created_by'] = $account->company_id;
  $user['created_by'] = $account->id;
  
  $company_email = $company['email'];

  $user = request('user');
  $user_email = $user['email'];

  $check_company = __action('entity_get_where','company',array("email"=>$company_email));

  if (count($check_company) > 0){
    log_error('A company with this account already exists!');
  }else{
  	$check_user = __action('entity_get_where','user',array("email"=>$user_email));
  	if (count($check_user) > 0){
      log_error('A user with this account already exists!');
  	}else{
      $password = $user['password'];
      $password2 = request('password');
      if ($password2 == $password && !empty($password)){
        $company_id = __action('entity_create','company',$company); 
        $user['company_id'] = $company_id;
        __action('entity_create','user',$user);
        log_success('Company Account created successfully.');
      }else{
        log_error('Invalid admin password!');
      }


  	}
   
  }

}
add_listener('uc_company_create','uc_company_create');
