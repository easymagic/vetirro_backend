<?php 

function uc_talent_consumer_register(){
 
 $post_data = request('post_data');
 $post_data['date_created'] = date('Y-m-d h:i:s');

 $talent_id = $post_data['talent_id'];

 __action('launch_usecase',array('talent','spam_count',$talent_id));
 $spam_count = response('spam_count');

 if ($spam_count > 0){
  //
 }else{
	 __action('entity_create','talent_consumer',$post_data);
	 log_success('Talent Assigned successfully'); 	
 }


}
add_listener('uc_talent_consumer_register','uc_talent_consumer_register');




