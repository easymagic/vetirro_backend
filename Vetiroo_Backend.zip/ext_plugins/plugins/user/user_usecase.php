<?php 

function uc_user_reset_password($user_id){
  $post_data = request('post_data');
  $password = $post_data['password'];
  $confirm_password = $post_data['confirm_password'];
  if ($password == $confirm_password && !empty($password)){
    __action('entity_where','id',$user_id);
    __action('entity_update','user',array("password"=>$password));
    log_success('Password changed successfully'); 
  }else{
  	log_error('Invalid Password!');
  }
}
add_listener('uc_user_reset_password','uc_user_reset_password');