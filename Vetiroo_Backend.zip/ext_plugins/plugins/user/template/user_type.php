<?php 
 //$type,
//$value

 $type_config = array();

 $type_config['admin'] = array('admin_staff','hmo','hospital');

 $type_config['admin_staff'] = array('hmo','hospital');

 $type_config['hmo'] = array('patient','hmo_staff');

 $type_config['hmo_staff'] = $type_config['doctor'] = $type_config['hospital_staff'] = array('patient');

 $type_config['hospital'] = array('doctor','hospital_staff');


?>
<select name="user[type]" class="form-control" data-value="<?php echo $value; ?>">
	<option value="">--Select Type--</option>
	<?php 
      foreach ($type_config[$type] as $k=>$v){

      	?>
        <option value="<?php echo $v; ?>"><?php echo $v; ?></option>
      	<?php 

      }
	?>
</select>