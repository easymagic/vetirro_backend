<form method="post" action="<?php echo base_url(); ?>actions/launch/admin/update/<?php echo $id; ?>">
<div class="col-xs-12">
	
<div class="col-xs-12" align="right">
	<?php 
     if (session('admin_account')->id != $item->id){
	?>
	<a href="<?php echo base_url(); ?>admin/<?php echo session('entity_type'); ?>" class="btn btn-primary">Back</a>
	<?php 
     }
	?>
</div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>

	<div class="col-xs-12">
      <h3>
      	Edit Profile (<?php echo ucfirst($item->type); ?>)
      </h3>
	</div>

 <?php 
 if ($item->type == 'patient'){
 ?>

<div class="col-xs-12">
	<label>Select Hospital</label>
</div>
<div class="col-xs-12 col-md-4">
	<?php echo __filter('get_dropdown_companies','hospital',$item->company_id2); ?>
</div>
<?php 
 }
?>


<!-- 	<div class="col-xs-12">
		<input type="text" name="email" class="form-control" />
	</div>
 -->

	<div class="col-xs-12">
		<label>
			<b>E-mail:&nbsp;<?php echo $item->email; ?></b>
		</label>
	</div>


	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" value="<?php echo $item->phone; ?>" name="post_data[phone]" placeholder="Phone" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="post_data[address]" value="<?php echo $item->address; ?>" placeholder="Address" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			User - Type
		</label>
	</div>
	<div class="col-xs-12 col-md-4">
		<b><?php echo ucfirst($item->type); ?></b>
	</div>





	<div class="col-xs-12">
	</div>
	<div class="col-xs-12">
		<input type="submit" value="Update" class="btn btn-primary" />
	</div>



</div>
</form>