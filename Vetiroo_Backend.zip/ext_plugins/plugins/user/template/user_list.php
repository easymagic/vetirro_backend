
<table class="table">
	<tr>
		<th>
			E-mail
		</th>
		<th>
			Phone
		</th>
		<th>
			Status
		</th>
		<th>
			Type
		</th>
	</tr>
	<?php 
      foreach ($data as $k=>$v){

      	?>

      	<tr>
      		<td>
      			<?php echo $v->email; ?>
      		</td>
      		<td>
      			<?php echo $v->phone; ?>
      		</td>
      		<td>
      			<?php 
                 if ($v->status == 1){
                   echo 'Activated';
                 }else{
                   echo 'Deactivated';
                 }
      			?>
      		</td>
      		<td>
      			<?php echo $v->type; ?>
      		</td>
      		<td>
      			<a href="<?php echo $config['edit_link'] . $v->id; ?>" class="btn btn-primary">Edit</a>

      			<a href="<?php echo $config['info_link'] . $v->id; ?>" class="btn btn-default">Info</a>


      		<?php
             if ($v->status == 0){
 ?>
      			<a href="<?php echo $config['update_action'] . $v->id; ?>?user[status]=1" class="btn btn-success confirm">Activate</a>
 <?php 
             }else{
?>
      			<a href="<?php echo $config['update_action'] . $v->id; ?>?user[status]=0" class="btn btn-danger confirm">Deactivate</a>
<?php 
             }
      		?>


      		</td>
      	</tr>

      	<?php 

      }
	?>
</table>