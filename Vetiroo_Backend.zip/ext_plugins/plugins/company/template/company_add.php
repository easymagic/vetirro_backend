<form method="post" action="<?php echo base_url(); ?>actions/launch/company/create">
<div class="col-xs-12">
	
<!-- <div class="col-xs-12" align="right">
	<a href="<?php echo base_url(); ?>company/<?php echo $type; ?>" class="btn btn-primary">Back</a>
</div>
 -->
<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>

	<div class="col-xs-12">
      <h3>
      	Add <?php echo ucfirst($type); ?>
      </h3>
	</div>

<!-- 	<div class="col-xs-12">
		<input type="text" name="email" class="form-control" />
	</div>
 -->

<div class="col-xs-12" style="
    border-bottom: 1px solid;
    margin-bottom: 10px;
    padding-bottom: 12px;
    width: 35%;
">
	<b>
		Company Detail
	</b>
</div>

	<div class="col-xs-12">
		<label>
			Company Name
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="company[name]" placeholder="Company Name" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			E-mail
		</label>
	</div>
	<div class="col-xs-12">
		<input type="email" name="company[email]" placeholder="E-mail" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="company[address]" placeholder="Address" class="form-control" />
	</div>



	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="company[phone]" placeholder="Phone" class="form-control" />
	</div>



   <input type="hidden" name="company[type]" value="<?php echo $type; ?>" />

<hr>

<div class="col-xs-12" style="
    border-bottom: 1px solid;
    margin-bottom: 10px;
    padding-bottom: 12px;
    width: 35%;
">
	<b>
		Setup <?php echo ucfirst($type); ?> Administrator
	</b>
</div>


	<div class="col-xs-12">
		<label>
			E-mail
		</label>
	</div>
	<div class="col-xs-12">
		<input type="email" name="user[email]" placeholder="Email" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="user[password]" placeholder="Password" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			Confirm Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="password" placeholder="Confirm Password" class="form-control" />
	</div>



	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[phone]" placeholder="Phone" class="form-control" />
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[address]" placeholder="Address" class="form-control" />
	</div>

   <input type="hidden" name="user[type]" value="staff" />
   <input type="hidden" name="user[status]" value="1" />






	<div class="col-xs-12">
	</div>
	<div class="col-xs-12">
		<input type="submit" value="Add" class="btn btn-primary" />
	</div>



</div>
</form>