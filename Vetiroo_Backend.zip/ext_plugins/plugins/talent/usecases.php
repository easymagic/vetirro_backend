<?php 

 function uc_talent_list(){
  $resp = __action('entity_get','talent');
  response('data',$resp);
 }
 add_listener('uc_talent_list','uc_talent_list');



 function uc_talent_register(){
  //use super-keys
  //surname,email,phone,bvn
  $post_data = request('post_data');
  $surname = $post_data['surname']; 	
  $email = $post_data['email'];
  $phone = $post_data['phone'];
  $bvn = $post_data['bvn'];

  $post_data['verified'] = 1;

  $criteria = array();
  $criteria['surname'] = $surname;
  $criteria['email'] = $email;
  $criteria['phone'] = $phone;
  $criteria['bvn'] = $bvn;

  $resp = __action('entity_get_where','talent',$criteria); 

  if (count() > 0){
   log_error('Registration previously made!');
  }else{
    __action('entity_create','talent',$post_data);
    log_success('Registration confirmed');
  }

 }
 add_listener('uc_talent_register','uc_talent_register');


 function uc_talent_spam_count($talent_id){
  $resp = __action('entity_get_where','talent',array("id"=>$talent_id));
  response('spam_count',$resp[0]->spam);
  if ($resp[0]->spam > 0){
   log_error('This individual has been marked as spam to a count of ' . $resp[0]->spam);
  }else{
   log_success('This individual is ok.');
  }
 }
 add_listener('uc_talent_spam_count','uc_talent_spam_count');